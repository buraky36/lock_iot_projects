#ifndef BLE_FRAME_PARSER_H
#define BLE_FRAME_PARSER_H

#include <stdint.h>
#include <stdbool.h>

#define BLE_FRAME_SOF 0x4F

// Protocol Message Types (Section 11.2)
#define BLE_MSG_TYPE_REQ    0x01 // REQUEST: Client -> Device, response expected
#define BLE_MSG_TYPE_RESP   0x02 // RESPONSE: Device -> Client
#define BLE_MSG_TYPE_EVENT  0x03 // EVENT: Device -> Client (unsolicited notify)
#define BLE_MSG_TYPE_CMD    0x04 // COMMAND: Server/App -> Device

// Protocol CMD codes (Section 11.3)
#define BLE_CMD_SESSION_INIT 0x70 // SESSION_INIT: Authenticate with localKey + ECDH
#define BLE_CMD_KEX_INIT     0x71 // KEX_INIT: Claim bootstrap ephemeral ECDH
#define BLE_CMD_KEY_DELIVER  0x72 // KEY_DELIVER: Deliver localKey (claim/rotate)
#define BLE_CMD_UNCLAIM      0x73 // UNCLAIM: Clear localKey & claim status

// Protocol Status codes (Section 11.4)
#define BLE_STATUS_OK               0x00
#define BLE_STATUS_AUTH_FAILED      0x01
#define BLE_STATUS_REPLAY_DETECTED  0x02
#define BLE_STATUS_ALREADY_CLAIMED  0x03
#define BLE_STATUS_NOT_CLAIMED      0x04
#define BLE_STATUS_TIMEOUT          0x05
#define BLE_STATUS_BUSY             0x06

typedef struct {
    uint8_t sof;
    uint8_t ver;
    uint8_t type;
    uint8_t cmd;
    uint16_t seq;
    uint16_t len;
    uint8_t status;
    uint64_t timestamp;
    uint8_t *payload;
    uint16_t crc;
} ble_frame_t;

uint16_t calc_crc16_ccitt(const uint8_t *data, uint16_t len);
bool ble_frame_parse(const uint8_t *data, uint16_t data_len, ble_frame_t *out_frame);
uint16_t ble_frame_build_req(uint8_t cmd, uint16_t seq, const uint8_t *payload, uint16_t payload_len, uint8_t *out_buf);
uint16_t ble_frame_build_resp(uint8_t cmd, uint16_t seq, uint8_t status, const uint8_t *payload, uint16_t payload_len, uint8_t *out_buf);
uint16_t ble_frame_build_event(uint8_t cmd, uint16_t seq, const uint8_t *payload, uint16_t payload_len, uint8_t *out_buf);

#endif // BLE_FRAME_PARSER_H
